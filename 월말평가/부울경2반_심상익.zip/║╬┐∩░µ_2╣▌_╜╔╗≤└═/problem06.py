############## 주의 ##############
# 입력을 받기위한 input 함수는 절대 사용하지 않습니다.
# 내장 함수 sum, min, max, len 함수를 사용하지 않습니다.
# 사용시 감점처리 되니 반드시 확인 바랍니다.
def caesar(word, num):
    pass
    # 여기에 코드를 작성하여 함수를 완성합니다.
    new_string = '' # 빈 문자열 생성
    for string in word: # 주어진 문자열 탐색
        if string.islower() is True: # 문자열 내 문자가 소문자 일 때
            total_num = ord(string) + num # 문자에 해당하는 정수로 변환 + n만큼 증가
            while total_num > 122: # 소문자 알파벳의 숫자 범위(97 ~ 122) 초과 시 범위에 들어올 때 까지 알파벳의 주기 26 만큼 감소시키는 while문
                total_num -= 26
                if total_num <= 122:
                    break
            result = chr(total_num) # 최종 숫자의 문자 반환
        elif string.isupper() is True: # 문자열 내 문자가 대문자 일 때
            total_num = ord(string) + num
            while total_num > 90: # 대문자는 범위(65 ~ 90)
                total_num -= 26
                if total_num <= 90:
                    break
            result = chr(total_num)
        new_string += result # n만큼 밀어낸 문자를 문자열에 추가
    return new_string # 최종 문자열 반환

# 아래 코드는 실행 확인을 위한 코드입니다.
if __name__ == '__main__':
    # 예시 코드는 수정하지 마세요.
    print(caesar('ssafy', 1))   # => ttbgz
    print(caesar('Python', 10)) # => Zidryx
    # 여기부터 아래에 추가 테스트를 위한 코드 작성 가능합니다.
    