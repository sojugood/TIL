############## 주의 ##############
# 입력을 받기위한 input 함수는 절대 사용하지 않습니다.
# 내장 함수 sum, min, max, len 함수를 사용하지 않습니다.
# 사용시 감점처리 되니 반드시 확인 바랍니다.
def get_row_col_maxsum(matrix):
    pass
    # 여기에 코드를 작성하여 함수를 완성합니다.
    row_sum_list = [] # 행의 합 리스트
    col_sum_list = [] # 열의 합 리스트
    for i in matrix: # 행의 합 구하기 위한 반복문
        row_sum = 0 # 각 행 별 행의 합
        count = 0 # 열의 합에서 사용하기 위한 행의 길이
        for j in i:
            row_sum += j
            count += 1
        row_sum_list.append(row_sum) # 행의 합 리스트에 각 행 별 합 추가
        range_count = count # 열의 합에서 범위로 사용하기 위해 변수로 재할당
    row_sum_list.sort(reverse=True) # 행의 합 리스트를 내림차순으로 정렬
    for j in range(range_count): # 열의 합 구하기 위한 반복문(행의 길이를 바탕으로 인덱스 번호 할당)
        col_sum = 0 # 각 열 별 열의 합
        for i in matrix: # 각 행 탐색
            col_sum += i[j] # 각 행 별 동일한 인덱스 번호 값들의 합 == 열의 합
        col_sum_list.append(col_sum) # 열의 합 리스트에 각 열 별 합 추가
    col_sum_list.sort(reverse=True) # 열의 합 리스트를 내림차순으로 정렬
    if row_sum_list[0] > col_sum_list[0]: # 행의 합 최댓값 과 열의 합 최댓값 비교
        return ('row', row_sum_list[0])
    elif col_sum_list[0] > row_sum_list[0]:
        return ('col', col_sum_list[0])


# 아래 코드는 실행 확인을 위한 코드입니다.
if __name__ == '__main__':
    # 예시 코드는 수정하지 마세요.
    example_matrix = [
        [1, 2, 3, 4],
        [5, 6, 7, 8],
        [9, 10, 11, 12],
        [13, 14, 15, 16]
    ]

    example_matrix2 = [
        [11, 5, 49, 20],
        [28, 16, 20, 33],
        [63, 17, 1, 15]
    ]
    print(get_row_col_maxsum(example_matrix))   # => ('row', 58)
    print(get_row_col_maxsum(example_matrix2))  # => ('col', 102)

    # 여기부터 아래에 추가 테스트를 위한 코드 작성 가능합니다.
    