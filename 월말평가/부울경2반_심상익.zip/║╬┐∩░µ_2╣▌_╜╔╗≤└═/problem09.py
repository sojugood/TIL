############## 주의 ##############
# 입력을 받기위한 input 함수는 절대 사용하지 않습니다.
# 내장 함수 sum, min, max, len 함수를 사용하지 않습니다.
# 사용시 감점처리 되니 반드시 확인 바랍니다.
def sum_digits(number):
    pass
    # 여기에 코드를 작성하여 함수를 완성합니다.
    if number // 10 == 0: # n이 한 자리 수 일 때(10으로 나눈 몫이 0일 때) n 반환
        return number
    else: # 그렇지 않을 경우, 재귀 함수
        number1 = number // 10 # 주어진 숫자를 10으로 나눈 몫을 새로운 숫자1 -> 숫자 제일 끝 자리 제외 나머지 부분
        number2 = number % 10 # 주어진 숫자를 10으로 나눈 나머지를 새로운 숫자 2 -> 숫자 제일 끝 자리
        return sum_digits(number1) + sum_digits(number2)
    
    
# 아래 코드는 실행 확인을 위한 코드입니다.
if __name__ == '__main__':
    # 예시 코드는 수정하지 마세요.
    print(sum_digits(123))  # => 6
    # 여기부터 아래에 추가 테스트를 위한 코드 작성 가능합니다.
